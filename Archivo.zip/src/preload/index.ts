import { contextBridge, ipcRenderer } from 'electron'
import { electronAPI } from '@electron-toolkit/preload'
import type { SondaApi } from '../shared/types'

const api: SondaApi = {
  sendRequest: (input) => ipcRenderer.invoke('http:send', input),
  cancelRequest: (requestId) => ipcRenderer.invoke('http:cancel', requestId),
  pickFile: () => ipcRenderer.invoke('files:pick'),
  listCollections: () => ipcRenderer.invoke('collections:list'),
  createCollection: (name) => ipcRenderer.invoke('collections:create', name),
  deleteCollection: (id) => ipcRenderer.invoke('collections:delete', id),
  readRequest: (path) => ipcRenderer.invoke('collections:readRequest', path),
  saveRequest: (input) => ipcRenderer.invoke('collections:saveRequest', input),
  deleteRequest: (path) => ipcRenderer.invoke('collections:deleteRequest', path),
  openWorkspace: () => ipcRenderer.invoke('collections:openWorkspace'),
  importSwagger: (url) => ipcRenderer.invoke('swagger:import', url),
  importPostman: () => ipcRenderer.invoke('postman:import'),
  exportPostman: (id) => ipcRenderer.invoke('postman:export', id),
  loadEnvironments: () => ipcRenderer.invoke('environments:load'),
  saveEnvironments: (data) => ipcRenderer.invoke('environments:save', data),
  previewSync: (id) => ipcRenderer.invoke('swagger:previewSync', id),
  applySync: (id, options) => ipcRenderer.invoke('swagger:applySync', id, options),
  listCookies: () => ipcRenderer.invoke('cookies:list'),
  deleteCookie: (id) => ipcRenderer.invoke('cookies:delete', id),
  clearCookies: () => ipcRenderer.invoke('cookies:clear'),
  loadSettings: () => ipcRenderer.invoke('settings:load'),
  saveSettings: (settings) => ipcRenderer.invoke('settings:save', settings)
}

if (process.contextIsolated) {
  try {
    contextBridge.exposeInMainWorld('electron', electronAPI)
    contextBridge.exposeInMainWorld('api', api)
  } catch (error) {
    console.error(error)
  }
} else {
  // @ts-ignore (define en index.d.ts)
  window.electron = electronAPI
  // @ts-ignore (define en index.d.ts)
  window.api = api
}
